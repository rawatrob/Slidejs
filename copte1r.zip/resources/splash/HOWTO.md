# How to Design Splash Images

Documentation on splash image sizing may be found here: http://docs.gameclosure.com/guide/manifest.html

Example splash images may be found under `devkit/projects/platformer/resources/splash`.

A default Game Closure splash will be inserted as a placeholder until one is specified.

