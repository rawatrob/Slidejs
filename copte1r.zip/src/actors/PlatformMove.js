import src.libs.Box2D.ImageViewB2d as ImageViewB2d;
import src.actors.WoodParticles as WoodParticles;
import ui.resource.Image as Image;
import src.libs.Box2D.Box2D as Box2D;
import math.geom.intersect as intersect;


var   b2Vec2 = Box2D.Common.Math.b2Vec2
            ,   b2BodyDef = Box2D.Dynamics.b2BodyDef
            ,   b2Body = Box2D.Dynamics.b2Body
            ,   b2FixtureDef = Box2D.Dynamics.b2FixtureDef
            ,   b2Fixture = Box2D.Dynamics.b2Fixture
            ,   b2World = Box2D.Dynamics.b2World
            ,   b2MassData = Box2D.Collision.Shapes.b2MassData
            ,   b2PolygonShape = Box2D.Collision.Shapes.b2PolygonShape
            ,   b2CircleShape = Box2D.Collision.Shapes.b2CircleShape
            ,   b2DebugDraw = Box2D.Dynamics.b2DebugDraw
            ;

var box_img = new Image({url: "resources/images/cat_run_001.png"});

exports = Class(ImageViewB2d, function (supr) {

    this.init = function (opts) {
        
         opts = merge(opts, {
          
           width:  box_img.getWidth(), //hole_back_img.getWidth(), // deberian ser 75
           height: box_img.getHeight(),//hole_back_img.getHeight() + mole_normal_img.getHeight()
            image: box_img
            
        });
      
        supr(this, 'init', [opts]);
        
       
        
    };
	this.collision = function(a,b){
	intersect.rectAndRect(a.style, b.style);
	}
    this.tick =function()
	{

	var b2Body = Box2D.Dynamics.b2Body;
var lister = Box2D.Dynamics.b2ContactListener;
if(!lister){console.log("tsgasdfs adfasdf sdaf");}

      
	 if (this.bodyB2d.GetType() == b2Body.b2_dynamicBody)
		{ 
		    position = this.bodyB2d.GetPosition();
		//	var hitcou = this.bodyB2d.GetContactList();
			//var GetFixture = this.bodyB2d.GetFixtureList();
			//var othershape = GetFixture.GetShape();
		
		var vel = this.bodyB2d.GetLinearVelocity();
		vel.y = 3;
		this.style.y = (position.y * this.scale) - 10; 
		 this.bodyB2d.SetLinearVelocity(vel);

		}
	
	}
 });